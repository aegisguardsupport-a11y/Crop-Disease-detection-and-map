# CPL Leaf Doctor — Hand-off Package

A trained, on-device crop-disease classifier ready to ship inside a React
Native (Expo) app. Drop this whole folder onto your dev machine and you
have everything needed to build the app and run it offline on Android or iOS.

## What's in this folder

```
handoff/
├── README.md                   ← you are here
├── expo_app/                   ← complete Expo project, ready to build
│   ├── App.tsx                 main UI (image picker → classify → top-3)
│   ├── src/
│   │   ├── preprocess.ts       resize → Float32Array (224×224, 0..255)
│   │   └── labels.ts           top-k decoder over 139 classes
│   ├── assets/
│   │   ├── cpl_crop_disease.tflite      ← 1.22 MB student model
│   │   └── cpl_id_to_label.json         ← class id → "crop::disease"
│   ├── package.json            all dependencies (Expo SDK 52)
│   ├── app.json                Expo config + native plugins
│   ├── eas.json                EAS Build profiles
│   ├── metro.config.js         registers .tflite as a bundleable asset
│   ├── README.md               full build instructions
│   └── …                       (other standard Expo files)
│
└── raw_model/                  ← the model + metadata as portable files
    ├── cpl_crop_disease.tflite        same .tflite as above (default quantization, 1.22 MB)
    ├── cpl_crop_disease_int8.tflite   alternate full-int8 build (1.33 MB)
    ├── cpl_id_to_label.json           139-class label map
    ├── cpl_preprocessing_config.json  input-size & batch-size config
    └── test_metrics.json              final test accuracy numbers
```

You really only need `expo_app/` to build the app. `raw_model/` is there
in case you want to integrate the model into something other than this
React Native template (a backend, a different mobile framework, etc.).

## The model in 30 seconds

- **Architecture:** MobileNetV3-Small (~1 M parameters), distilled from a 93.6%-accurate EfficientNetB2 teacher trained on a 65,000-image, 139-class plant-disease dataset.
- **Format:** TensorFlow Lite, dynamic-range int8 quantized, 1.22 MB.
- **Test-set accuracy** (9,802 held-out images):
  - Top-1: **87.4%**
  - Top-3: **97.8%**
- **Input:** float32 tensor, shape `(1, 224, 224, 3)`, RGB pixels in **0..255** (NOT 0..1; MobileNetV3 normalises internally), bilinear resize.
- **Output:** float32 tensor, shape `(1, 139)`, softmax probabilities. `argmax` gives the class id; map via `cpl_id_to_label.json`. Labels follow the format `crop::disease`, e.g. `tomato::Late_blight`.

## Quick start (for the React Native developer)

Read `expo_app/README.md` for the full walkthrough; the short version is:

```bash
# 1. Get the dependencies
cd expo_app
npm install

# 2. Log into Expo (free account)
npm install -g eas-cli
eas login

# 3. First-time project init (creates an EAS projectId)
eas build:configure

# 4. Build the dev client (~10 min on EAS, no local build chain needed)
eas build --profile development --platform android
# or
eas build --profile development --platform ios   # needs Mac + Apple device UUID

# 5. Install the resulting APK / iOS build on a real device
#    (Expo Go won't work — TFLite is a native module. The dev client is required.)

# 6. Start Metro and run the app
npm start
# scan the QR code with the dev client (NOT Expo Go)
```

After that, every code change hot-reloads instantly. You only have to
rebuild the dev client when you change native dependencies.

### Verifying offline operation

Once the app is running on the device:

1. Put it in airplane mode.
2. Pick or take a leaf photo.
3. The classifier still works.

No network calls happen during inference. The .tflite file is bundled
into the app binary on install.

## Things to know before you build

- **Expo Go is not enough.** `react-native-fast-tflite` is a native
  module. You **must** build a custom dev client (`eas build --profile
  development`) once. Plain Expo Go will throw "Native module
  RNFastTflite not found".
- **Test on a real device.** The iOS Simulator doesn't run TFLite
  cleanly without extra config. Plug in a physical phone instead — much
  less hassle.
- **Don't change the input contract.** If you replace
  `src/preprocess.ts`, keep the input as float32 in `[0, 255]` at
  224×224 RGB. MobileNetV3 has a built-in normalisation layer that
  expects raw pixel values; passing `[0, 1]` will produce confidently
  wrong predictions.
- **The model is closed-world.** It will confidently mis-label any
  input that's not one of the 139 trained crop-disease combinations
  (non-plant images, unfamiliar crops, etc.). Treat the predicted
  probability as a soft confidence indicator, not a rejection signal.

## If you want to use the model outside the React Native app

Use the files in `raw_model/`. The .tflite file is loadable by:

- Python: `tf.lite.Interpreter(model_path='cpl_crop_disease.tflite')`
- Android Java/Kotlin: `org.tensorflow.lite.Interpreter`
- iOS Swift: `TensorFlowLite.Interpreter`
- Browser / Node: `@tensorflow/tfjs-tflite`
- Edge devices: any standard TFLite runtime (Coral, Raspberry Pi, etc.)

The input/output contract above is the same in every environment.

## Performance you can expect

| Device | Inference time | Total user-perceived latency |
|---|---|---|
| iPhone 14 / 15 (A15+) | ~10 ms | ~150 ms |
| Pixel 7 / 8 (Tensor G2/G3) | ~15 ms | ~200 ms |
| Mid-range Android (SD 6xx) | ~30 ms | ~300 ms |

Total latency is dominated by the JPEG decode in JavaScript. If you
need real-time camera classification (>5 fps), swap `expo-image-picker`
for `react-native-vision-camera` + `vision-camera-resize-plugin` to feed
raw frames directly to TFLite. The README inside `expo_app/` explains how.

## Provenance / "is this really your model?"

If anyone asks where the model came from, the original training notebook
plus full provenance artifacts (teacher's per-epoch loss curves,
distillation training log, dataset hashes, etc.) are kept in the parent
project. The .tflite file in `raw_model/` came from running
`exports/cpl_mobilenet_kd.tflite` through the standard
`tf.lite.TFLiteConverter` pipeline — nothing remote, no external
downloads beyond ImageNet pretraining.

## Questions / problems

If something doesn't build or predictions look wrong, the most common
fixes are in `expo_app/README.md` under **Troubleshooting**. The two
things that catch everyone the first time:

1. Trying to run in Expo Go (won't work — needs the custom dev client).
2. Forgetting that input pixels are 0..255, not 0..1.
