import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import * as ImagePicker from "expo-image-picker";
import { useTensorflowModel } from "react-native-fast-tflite";

import { preprocessImage } from "./src/preprocess";
import { topKPredictions, type Prediction } from "./src/labels";

export default function App() {
  // Loads the .tflite from assets/. The hook returns
  // { state: 'loading' | 'loaded' | 'error', model?, error? }.
  const model = useTensorflowModel(require("./assets/cpl_crop_disease.tflite"));

  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [predictions, setPredictions] = useState<Prediction[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);

  const classify = useCallback(
    async (uri: string) => {
      if (model.state !== "loaded") {
        Alert.alert("Model not ready", "The model is still loading. Try again in a second.");
        return;
      }
      setBusy(true);
      setPredictions(null);
      try {
        const { data, previewUri: resizedUri } = await preprocessImage(uri);
        setPreviewUri(resizedUri);

        const t0 = Date.now();
        const out = model.model.runSync([data]);
        const elapsed = Date.now() - t0;
        setLatencyMs(elapsed);

        const probs = out[0] as Float32Array;
        setPredictions(topKPredictions(probs, 3));
      } catch (err) {
        Alert.alert("Classification failed", String(err));
      } finally {
        setBusy(false);
      }
    },
    [model]
  );

  const pickFromLibrary = useCallback(async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("Permission required", "Photo library access is needed.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
    if (!result.canceled && result.assets[0]) {
      await classify(result.assets[0].uri);
    }
  }, [classify]);

  const takePhoto = useCallback(async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("Permission required", "Camera access is needed.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
    if (!result.canceled && result.assets[0]) {
      await classify(result.assets[0].uri);
    }
  }, [classify]);

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>CPL Leaf Doctor</Text>
        <Text style={styles.subtitle}>
          Offline crop-disease detection · 139 classes · MobileNetV3-Small (distilled)
        </Text>

        <View style={styles.modelStatus}>
          {model.state === "loading" && <Text style={styles.muted}>Loading model…</Text>}
          {model.state === "error" && (
            <Text style={styles.error}>Model failed to load: {String(model.error)}</Text>
          )}
          {model.state === "loaded" && (
            <Text style={styles.muted}>Model loaded · ready</Text>
          )}
        </View>

        <View style={styles.buttonRow}>
          <Pressable
            style={[styles.button, busy || model.state !== "loaded" ? styles.buttonDisabled : null]}
            disabled={busy || model.state !== "loaded"}
            onPress={takePhoto}
          >
            <Text style={styles.buttonLabel}>Take photo</Text>
          </Pressable>
          <Pressable
            style={[styles.button, busy || model.state !== "loaded" ? styles.buttonDisabled : null]}
            disabled={busy || model.state !== "loaded"}
            onPress={pickFromLibrary}
          >
            <Text style={styles.buttonLabel}>Pick from library</Text>
          </Pressable>
        </View>

        {previewUri && (
          <Image source={{ uri: previewUri }} style={styles.preview} resizeMode="cover" />
        )}

        {busy && (
          <View style={styles.loading}>
            <ActivityIndicator />
            <Text style={styles.muted}>Classifying…</Text>
          </View>
        )}

        {predictions && (
          <View style={styles.predictions}>
            {latencyMs !== null && (
              <Text style={styles.muted}>Inference: {latencyMs} ms</Text>
            )}
            {predictions.map((p) => (
              <View key={p.classId} style={styles.predictionRow}>
                <View style={styles.predictionText}>
                  <Text style={styles.predictionTitle}>
                    {p.rank}. {p.crop}
                  </Text>
                  <Text style={styles.predictionDisease}>{p.disease || "(no disease)"}</Text>
                </View>
                <Text style={styles.predictionPct}>{(p.confidence * 100).toFixed(1)}%</Text>
              </View>
            ))}
          </View>
        )}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Test-set accuracy: 87.4% top-1 / 97.8% top-3 · 1.2 MB on-device model · zero network
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#103a1a" },
  content: { padding: 20, paddingTop: 60, gap: 16 },
  title: { fontSize: 28, fontWeight: "700", color: "#fff" },
  subtitle: { color: "#bcd5c2", fontSize: 14, marginBottom: 4 },
  modelStatus: { paddingVertical: 4 },
  muted: { color: "#bcd5c2", fontSize: 13 },
  error: { color: "#ffb4b4", fontSize: 13 },
  buttonRow: { flexDirection: "row", gap: 12 },
  button: {
    flex: 1,
    backgroundColor: "#3aa757",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
  },
  buttonDisabled: { opacity: 0.5 },
  buttonLabel: { color: "#fff", fontWeight: "600", fontSize: 15 },
  preview: { width: "100%", aspectRatio: 1, borderRadius: 16, backgroundColor: "#0a2010" },
  loading: { flexDirection: "row", alignItems: "center", gap: 12 },
  predictions: {
    backgroundColor: "#0a2010",
    borderRadius: 16,
    padding: 16,
    gap: 14,
    borderColor: "#3aa757",
    borderWidth: 1,
  },
  predictionRow: { flexDirection: "row", alignItems: "center" },
  predictionText: { flex: 1 },
  predictionTitle: { color: "#fff", fontSize: 16, fontWeight: "600", textTransform: "capitalize" },
  predictionDisease: { color: "#bcd5c2", fontSize: 14 },
  predictionPct: { color: "#3aa757", fontSize: 18, fontWeight: "700", minWidth: 64, textAlign: "right" },
  footer: { paddingTop: 12, borderTopColor: "#1f4a2a", borderTopWidth: 1 },
  footerText: { color: "#7ea287", fontSize: 12, textAlign: "center" },
});
