import labelsRaw from "../assets/cpl_id_to_label.json";

const labelsByIndex: string[] = (() => {
  const arr = new Array<string>(Object.keys(labelsRaw).length);
  for (const [k, v] of Object.entries(labelsRaw as Record<string, string>)) {
    arr[Number(k)] = v;
  }
  return arr;
})();

export type Prediction = {
  rank: number;
  classId: number;
  label: string;
  crop: string;
  disease: string;
  confidence: number;
};

/**
 * Convert a 139-vector of softmax probabilities into the top-k named
 * predictions. `topK` defaults to 3.
 */
export function topKPredictions(
  probs: Float32Array | number[],
  topK = 3
): Prediction[] {
  const indexed: Array<[number, number]> = [];
  for (let i = 0; i < probs.length; i++) {
    indexed.push([i, probs[i] as number]);
  }
  indexed.sort((a, b) => b[1] - a[1]);

  return indexed.slice(0, topK).map(([classId, confidence], i) => {
    const label = labelsByIndex[classId] ?? `class_${classId}`;
    const [crop, disease] = label.split("::");
    return {
      rank: i + 1,
      classId,
      label,
      crop,
      disease: disease ?? "",
      confidence,
    };
  });
}

export const NUM_CLASSES = labelsByIndex.length;
