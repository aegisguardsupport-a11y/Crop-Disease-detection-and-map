/**
 * Image preprocessing for the CPL crop-disease classifier (MobileNetV3-Small student).
 *
 * The model expects a tensor of shape (1, 224, 224, 3), float32, with pixel
 * values in [0, 255] (NOT [0, 1] — MobileNetV3 has its own internal
 * preprocessing). We:
 *   1. Resize the image to 224x224 with Expo's image manipulator (fast,
 *      runs on the GPU on iOS and the native bitmap pipeline on Android).
 *   2. Re-encode as JPEG and read it as base64.
 *   3. Decode the JPEG to raw RGBA pixels with the pure-JS jpeg-js library.
 *   4. Drop the alpha channel and copy R/G/B into a Float32Array.
 *
 * Pure JS decode adds ~50–100 ms on a modern phone. If you ever need
 * realtime camera classification (>5 fps), switch to react-native-vision-camera
 * + vision-camera-resize-plugin so you get the pixel buffer directly.
 */

import * as ImageManipulator from "expo-image-manipulator";
import { Buffer } from "buffer";
import jpeg from "jpeg-js";

export const INPUT_SIZE = 224;
export const INPUT_PIXEL_COUNT = INPUT_SIZE * INPUT_SIZE * 3;

export type Preprocessed = {
  /** Float32Array of length 1 * 260 * 260 * 3 = 202_800. */
  data: Float32Array;
  /** Convenience field: the resized JPEG URI for displaying in the UI. */
  previewUri: string;
};

/**
 * Resize, decode, and convert an image at `uri` into the model's input tensor.
 */
export async function preprocessImage(uri: string): Promise<Preprocessed> {
  // 1. Resize to 260x260 RGB JPEG. Use the highest quality so we don't add
  //    artefacts that change the prediction.
  const resized = await ImageManipulator.manipulateAsync(
    uri,
    [{ resize: { width: INPUT_SIZE, height: INPUT_SIZE } }],
    {
      base64: true,
      compress: 1,
      format: ImageManipulator.SaveFormat.JPEG,
    }
  );

  if (!resized.base64) {
    throw new Error("Image manipulator did not return base64 data");
  }

  // 2. Decode JPEG bytes -> raw RGBA pixels.
  const jpegBytes = Buffer.from(resized.base64, "base64");
  const { data: rgbaPixels, width, height } = jpeg.decode(jpegBytes, {
    useTArray: true,
  });

  if (width !== INPUT_SIZE || height !== INPUT_SIZE) {
    throw new Error(
      `Unexpected resized image dimensions: ${width}x${height} (expected ${INPUT_SIZE}x${INPUT_SIZE})`
    );
  }

  // 3. Convert RGBA uint8 -> RGB float32 in [0, 255].
  const out = new Float32Array(INPUT_PIXEL_COUNT);
  for (let src = 0, dst = 0; src < rgbaPixels.length; src += 4, dst += 3) {
    out[dst] = rgbaPixels[src]; // R
    out[dst + 1] = rgbaPixels[src + 1]; // G
    out[dst + 2] = rgbaPixels[src + 2]; // B
    // alpha channel ignored
  }

  return { data: out, previewUri: resized.uri };
}
