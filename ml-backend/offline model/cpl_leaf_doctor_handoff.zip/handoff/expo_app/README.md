# CPL Leaf Doctor — Offline Expo App

A React Native (Expo) app that runs the CPL crop-disease classifier
**fully offline** on the user's device. Pick a leaf photo from the
camera or gallery; get the top-3 (crop, disease) predictions in ~50–200
milliseconds with zero network calls.

The model is a **MobileNetV3-Small** student distilled from a 93.6%-accurate
EfficientNetB2 teacher trained on a balanced 139-class plant-disease dataset.
It ships as a quantized **1.2 MB TFLite** file and reaches **87.4% top-1
accuracy / 97.8% top-3 accuracy** on the held-out 9,802-image test set.

## Architecture

```
┌─────────────────────────────────┐
│ App.tsx                         │  Top-level UI + state.
│   ├── useTensorflowModel(...)   │  Loads cpl_crop_disease.tflite (lazy).
│   └── ImagePicker / Camera      │  expo-image-picker.
│
├─ src/preprocess.ts              │  Resize -> 224x224 -> Float32Array (RGB, 0..255).
├─ src/labels.ts                  │  Top-k decoder over the 139 classes.
└─ assets/
     cpl_crop_disease.tflite      │  ~1.2 MB student model (bundled).
     cpl_id_to_label.json         │  Class id -> "crop::disease" map.
```

Inference engine: [`react-native-fast-tflite`](https://github.com/mrousavy/react-native-fast-tflite) — calls native iOS Core ML / Android NNAPI / GPU delegates under the hood. **NOT** TensorFlow.js; that's slower and unsuitable for this model size.

## Why this can't run in plain Expo Go

`react-native-fast-tflite` is a native module. Plain Expo Go cannot load
unknown native modules. You need either:

- **Expo Dev Client** (recommended, stays in managed workflow), built once
  with EAS Build, then iterate normally with `expo start --dev-client`.
- **Bare workflow** (`npx expo prebuild`), if you want native projects on
  disk that you can edit directly.

This template targets the Dev Client path.

## Prerequisites

| Tool | Why |
|---|---|
| Node.js 18+ | Expo CLI runtime |
| `npm` or `yarn` | dependency install |
| `eas-cli` (`npm install -g eas-cli`) | building the dev client |
| An Expo account (free) | EAS Build needs it |
| iOS: macOS + Xcode 15+ (only for iOS native build) | optional, can skip and target Android only |
| Android: nothing locally — EAS builds in the cloud | |
| A physical iOS or Android device | TFLite models don't run on iOS simulator without extra work; testing on a real device is the easy path |

## One-time setup

```bash
# 1. Install dependencies
cd mobile_app
npm install

# 2. Log in to EAS (first time only)
eas login

# 3. Configure the project (creates the EAS project id on the server side)
eas build:configure
```

The last command will fill in `expo.extra.eas.projectId` in `app.json`.

## Build a development client

Pick whichever platform you have a device for.

### Android (no Mac needed)

```bash
eas build --profile development --platform android
```

EAS uploads your project to its build farm and produces an `.apk`.
You'll get a QR code / link in the terminal. Open it on your Android
phone, install the APK (you may need to allow "install from unknown
sources"), and you now have the dev client installed.

### iOS

```bash
eas build --profile development --platform ios
```

For internal distribution you'll be prompted to register your device
UUID — `eas device:create` walks you through it. Open the resulting
build link on your iPhone to install.

## Run the app on the dev client

```bash
npm start
# scan the QR code with the dev client (NOT Expo Go)
```

The Metro bundler will push your JS bundle to the dev client over LAN.
`assets/cpl_crop_disease.tflite` is bundled into the JS bundle as a
binary asset (see `metro.config.js` and `app.json` `assetBundlePatterns`).

## Verifying offline operation

Once the app is running on your device:

1. Put the device into airplane mode.
2. Pick / take a photo.
3. The classifier still works.

That's it — there is no network call anywhere in the inference path.
The only network calls happen during development (Metro bundler) and
the first time you install the dev client.

## Performance notes (typical, on the new MobileNetV3-Small student)

| Device | Inference time | Total user-perceived latency |
|---|---|---|
| iPhone 14 (A15 Bionic) | ~10 ms | ~150 ms |
| Pixel 7 (Tensor G2) | ~15 ms | ~200 ms |
| Mid-range Android (Snapdragon 6xx) | ~30 ms | ~300 ms |

The pure-JS JPEG decoder in `src/preprocess.ts` is the slowest single
step. If you need >5 fps live classification, swap it for
`react-native-vision-camera` + `vision-camera-resize-plugin` so the
camera feeds the model raw pixel buffers.

## Updating the model

If you retrain and produce a new `.tflite`:

1. Drop the new file at `assets/cpl_crop_disease.tflite`.
2. If you also re-derived the label set, replace
   `assets/cpl_id_to_label.json`.
3. Reload the dev client (`r` in the Metro terminal). The new model is
   picked up automatically.

For production releases (`eas build --profile production`) you must
rebuild the binary because the asset is bundled.

## Production / Play Store / App Store

Run:

```bash
eas build --profile production --platform android   # .aab for Play
eas build --profile production --platform ios       # for App Store / TestFlight
```

The 1.2 MB model bundled inside the binary is well under the 150 MB Play
Store and 4 GB App Store limits. No on-device download needed.

## Input / output contract (for anyone integrating this model elsewhere)

If you want to load `assets/cpl_crop_disease.tflite` from somewhere
other than this Expo app, the input/output contract is:

| | |
|---|---|
| Input shape | `(1, 224, 224, 3)` |
| Input dtype | `float32` |
| Input pixel range | `[0.0, 255.0]` (NOT 0..1; MobileNetV3 normalises internally) |
| Resize method | bilinear |
| Output shape | `(1, 139)` |
| Output dtype | `float32` |
| Output meaning | softmax probabilities over the 139 classes |
| Class names | `assets/cpl_id_to_label.json`, format `crop::disease` |

## Troubleshooting

- **`useTensorflowModel returned error: Failed to load model`** — usually
  means Metro didn't bundle the `.tflite`. Verify `metro.config.js`
  registers the `tflite` asset extension and that the file is at
  `assets/cpl_crop_disease.tflite`.
- **`Native module RNFastTflite not found`** — you're running in Expo Go.
  Build and install the dev client.
- **All predictions look random / nonsensical** — the input tensor is
  probably normalised wrong. MobileNetV3 expects float32 in `[0, 255]`
  (NOT `[0, 1]`). The bundled `preprocess.ts` already does this; if you
  swap it, keep that contract.
- **iOS build fails on Apple Silicon Mac** — make sure you've installed
  Xcode 15+ from the App Store, not just the Command Line Tools.

## License

Codebase shared as part of a hackathon submission. The trained weights
and the source dataset are governed separately.
