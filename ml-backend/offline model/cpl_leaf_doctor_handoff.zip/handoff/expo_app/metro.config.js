// Make Metro bundle .tflite (and a few other binary formats) as static assets.
// Required so that `require('./assets/cpl_crop_disease.tflite')` resolves
// to a real on-device file path that react-native-fast-tflite can open.

const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

config.resolver.assetExts = [
  ...config.resolver.assetExts,
  "tflite",
  "bin",
];

module.exports = config;
